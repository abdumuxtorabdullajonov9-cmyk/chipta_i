"""
URL configuration for chipta_uz project.
"""
# chipta_uz/urls.py
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from ilova.views import (
    CustomerEventListView,
    AdminDashboardView,
    MyTicketsView,
    FakePaymentView,
    TicketPurchasePageView,
    UserRegisterView,
    UserLoginView,
    UserLogoutView,
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('ilova.urls')),

    # Bosh sahifa
    path('', CustomerEventListView.as_view(), name='home'),

    # Qolgan HTML sahifalar yo'nalishlari
    path('dashboard/', AdminDashboardView.as_view(), name='dashboard_page'),
    path('ticket-3d/<int:event_id>/', TicketPurchasePageView.as_view(), name='ticket_3d_page'),
    path('accounts/', include('allauth.urls')),

    # MUHIM TUZATISH: bu 3 ta marshrut avval faqat ilova/urls.py da, /api/ prefiksi
    # bilan mavjud edi (/api/auth/login/ va h.k.), settings.LOGIN_URL va
    # handle_no_permission() esa /auth/login/ (prefikssiz) manzilga yo'naltirar edi —
    # bu 404 ga olib kelardi. Endi haqiqiy, mos manzillar shu yerda ro'yxatga olindi.
    path('auth/register/', UserRegisterView.as_view(), name='register'),
    path('auth/login/', UserLoginView.as_view(), name='login'),
    path('auth/logout/', UserLogoutView.as_view(), name='logout'),

    # To'lov va Chiptalar sahifalari
    path('my-tickets/', MyTicketsView.as_view(), name='my_tickets'),
    path('orders/pay-fake/<uuid:order_id>/', FakePaymentView.as_view(), name='fake_payment'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


#111927018459-66fm8846dbe22qanj5tqp46g6b1sd5qa.apps.googleusercontent.com
#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

