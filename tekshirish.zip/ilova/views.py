from django.views.generic import ListView, TemplateView
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db import transaction
from django.http import HttpResponse

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAdminUser

from .models import Event, EventSeat, Order, Ticket, StadiumSector, SectorGroup, Seat
from .serializers import CustomerEventSeatListSerializer
from .services import reserve_seats_service, confirm_fake_payment_service, release_expired_reservations
from .utils import render_to_pdf


# --- AUTENTIFIKATSIYA (RO'YXATDAN O'TISH, KIRISH, CHIQISH) ---

class UserRegisterView(View):
    def get(self, request):
        return render(request, 'register.html', {'next': request.GET.get('next', '')})

    def post(self, request):
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        next_url = request.POST.get('next', '')

        if User.objects.filter(username=username).exists():
            return render(request, 'register.html',
                          {'error': 'Ushbu foydalanuvchi nomi allaqachon mavjud.', 'next': next_url})

        # Foydalanuvchini yaratamiz
        user = User.objects.create_user(username=username, email=email, password=password)

        # Django chalkashmasligi uchun backendni aniq ko'rsatamiz (bir nechta
        # AUTHENTICATION_BACKENDS mavjud bo'lgani uchun buni Django talab qiladi)
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')

        if next_url:
            return redirect(next_url)
        return redirect('home')


class UserLoginView(View):
    def get(self, request):
        return render(request, 'login.html', {'next': request.GET.get('next', '')})

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        next_url = request.POST.get('next', '')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if next_url:
                return redirect(next_url)
            return redirect('home')
        return render(request, 'login.html', {'error': 'Foydalanuvchi nomi yoki parol xato!', 'next': next_url})


class UserLogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('home')


# --- MIJOZ SAHIFALARI JARAYONI (HOME, 3D SAHIFA, TO'LOV, CHIPTALAR) ---

class CustomerEventListView(View):
    def get(self, request):
        events = Event.objects.filter(is_active=True).order_by('date')
        return render(request, 'home.html', {'events': events})


class TicketPurchasePageView(LoginRequiredMixin, View):
    """
    3D o'rindiq tanlash sahifasi.

    MUHIM TUZATISH: bu avval oddiy `TemplateView.as_view(template_name='ticket_purchase.html')`
    edi — na login talab qilinar, na event_id sahifaga uzatilar edi. Natijada sahifa
    haqiqiy bazadagi Event/EventSeat bilan umuman bog'lanmagan, sof frontend
    "makony" (mock) sifatida ishlar edi (joylar Math.random() bilan chizilar,
    "Sotib olish" tugmasi esa hamisha bitta qattiq yozilgan (hardcoded) buyurtma
    ID'siga yo'naltirardi). Endi haqiqiy Event bazadan olinib, shablonga uzatiladi.
    """
    def get(self, request, event_id):
        event = get_object_or_404(Event, id=event_id, is_active=True)
        return render(request, 'ticket_purchase.html', {'event': event})


class FakePaymentView(LoginRequiredMixin, View):
    """
    Click/Payme o'rniga ishlaydigan soxta (test) to'lov sahifasi.

    MUHIM TUZATISH: avval bu view `order_id` parametrini DEARLIK ishlatmasdi —
    har safar bazadagi ixtiyoriy bo'sh joyni tasodifiy tanlab, unga yangi
    buyurtma yaratardi. Ya'ni foydalanuvchi 3D xaritada aynan qaysi joyni
    tanlagan bo'lishidan qat'iy nazar, unga umuman boshqa (tasodifiy) joy
    sotilardi, tanlangan joy esa "RESERVED" holatida abadiy osilib qolardi.
    Endi bu view haqiqiy buyurtmani (order_id bo'yicha, faqat shu foydalanuvchiga
    tegishli bo'lsa) topib, aynan o'sha buyurtmadagi joylarni tasdiqlaydi.
    """
    def get(self, request, order_id):
        order = get_object_or_404(Order, id=order_id, user=request.user)
        if order.status != 'PENDING':
            return redirect('my_tickets')
        return render(request, 'fake_payment.html', {'amount': order.total_amount, 'order_id': order.id})

    def post(self, request, order_id):
        order = get_object_or_404(Order, id=order_id, user=request.user)
        try:
            confirm_fake_payment_service(order.id)
        except ValidationError as e:
            return render(request, 'fake_payment.html', {
                'amount': order.total_amount,
                'order_id': order.id,
                'error': str(e),
            })
        return redirect('my_tickets')


class MyTicketsView(LoginRequiredMixin, ListView):
    model = Ticket
    template_name = 'my_tickets.html'
    context_object_name = 'tickets'

    def get_queryset(self):
        return Ticket.objects.filter(order__user=self.request.user).order_by('-created_at')


# --- BACKEND REST API SATHI (JOYLAR, ZAXIRA QILISH, DASHBOARD) ---

class EventSeatListView(APIView):
    """
    3D sahifa ochilgan sektorning 625 ta joyini (holati va narxi bilan) shu yerdan
    so'raydi. MUHIM TUZATISH: bu endpoint avval umuman mavjud emas edi — shuning
    uchun frontend har bir sektor uchun joy holatini (bo'sh/band) Math.random()
    bilan "o'ylab topar" edi.
    """
    def get(self, request, event_id, sector_number):
        release_expired_reservations()
        sector = get_object_or_404(StadiumSector, name=str(sector_number))
        seats = (
            EventSeat.objects
            .filter(event_id=event_id, seat__sector=sector)
            .select_related('seat')
            .order_by('seat__row_number', 'seat__seat_number')
        )
        data = CustomerEventSeatListSerializer(seats, many=True).data
        return Response(data)


class ReserveSeatView(APIView):
    def post(self, request):
        if not request.user.is_authenticated:
            return Response({"error": "Iltimos, tizimga kiring."}, status=status.HTTP_401_UNAUTHORIZED)

        event_seat_ids = request.data.get('event_seat_ids', [])
        if not event_seat_ids:
            return Response({"error": "Sektor ichidan kamida bitta o'rindiq tanlang."},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            order = reserve_seats_service(request.user, event_seat_ids)
            return Response({"order_id": str(order.id)}, status=status.HTTP_201_CREATED)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class AdminDashboardEventCreateView(APIView):
    # MUHIM TUZATISH: avval `permission_classes = []` (ya'ni AllowAny) edi — bu
    # tizimga kirmagan har qanday odam ham (masalan API manzilini bilib, to'g'ridan
    # to'g'ri so'rov yuborib) 20 000 tagacha joy bilan yangi o'yin yaratishi mumkin
    # bo'lgan JIDDIY XAVFSIZLIK TESHIGI edi.
    permission_classes = [IsAdminUser]

    def post(self, request):
        title = request.data.get('title')
        description = request.data.get('description', '')
        date = request.data.get('date')
        sector_prices = request.data.get('sector_prices', {})

        if not title or not date:
            return Response({"error": "Uchrashuv nomi va vaqti majburiy!"}, status=status.HTTP_400_BAD_REQUEST)

        with transaction.atomic():
            # 1. Yangi uchrashuv (Event) yaratamiz
            event = Event.objects.create(title=title, description=description, date=date)

            # 2. Bazadagi hamma o'rindiqlarni olamiz
            all_seats = Seat.objects.all().select_related('sector')

            event_seats = []
            for seat in all_seats:
                # Aqlli qidiruv: "1-sektor", "1" yoki shunchaki guruh narxini tekshiramiz
                sector_name = seat.sector.name

                # Frontenddan kelishi mumkin bo'lgan barcha formatlarni qidirib ko'ramiz
                price = (
                        sector_prices.get(f"{sector_name}-sektor") or
                        sector_prices.get(sector_name) or
                        getattr(seat.sector.group, 'default_price', 50000.00)
                )

                event_seats.append(
                    EventSeat(
                        event=event,
                        seat=seat,
                        price=float(price),
                        status='AVAILABLE'
                    )
                )

            # 3. Barcha chiptalarni PostgreSQL ichiga ultra-tezkor bulk_create bilan yozamiz
            EventSeat.objects.bulk_create(event_seats)

        return Response({"message": f"Yangi uchrashuv va {len(event_seats)} ta chipta generatsiya qilindi."},
                        status=status.HTTP_201_CREATED)


class AdminDashboardEventListView(APIView):
    permission_classes = [IsAdminUser]  # MUHIM TUZATISH: avval ochiq edi

    def get(self, request):
        events = Event.objects.all().order_by('-date')
        return Response([{"id": e.id, "title": e.title, "date": e.date.strftime("%Y-%m-%d %H:%M")} for e in events])


class AdminSectorGroupConfigView(APIView):
    permission_classes = [IsAdminUser]  # MUHIM TUZATISH: avval ochiq edi

    def get(self, request):
        groups = [{"id": g.id, "name": g.name, "color_class": g.color_class, "default_price": float(g.default_price),
                   "sector_ids": list(g.sectors.values_list('id', flat=True))} for g in SectorGroup.objects.all()]
        sectors = [{"id": s.id, "name": s.name, "group_id": s.group_id} for s in StadiumSector.objects.all()]
        return Response({"groups": groups, "sectors": sectors})

    def post(self, request):
        name = request.data.get('name')
        color_class = request.data.get('color_class')
        sector_ids = request.data.get('sector_ids', [])
        group, _ = SectorGroup.objects.update_or_create(name=name, defaults={"color_class": color_class})
        if sector_ids:
            StadiumSector.objects.filter(id__in=sector_ids).update(group=group)
        return Response({"message": "Saqlandi"})


class DownloadTicketPDFView(LoginRequiredMixin, View):
    def get(self, request, ticket_uid):
        # Chiptani bazadan (PostgreSQL) unikal UID kodi orqali qidirib topamiz —
        # va bu chipta so'rov yuborayotgan foydalanuvchining o'ziga tegishli
        # ekanligini tekshiramiz (boshqa birovning chiptasini yuklab olib
        # bo'lmasligi uchun).
        ticket = get_object_or_404(
            Ticket.objects.select_related('event_seat__seat__sector', 'event_seat__event', 'order__user'),
            ticket_uid=ticket_uid,
            order__user=request.user,
        )

        # Andoza (HTML) ichiga o'tadigan ma'lumotlar ombori
        context = {
            'ticket': ticket,
            'event': ticket.event_seat.event,
            'seat': ticket.event_seat.seat,
            'sector': ticket.event_seat.seat.sector,
        }

        # PDF drayverini ishga tushiramiz
        pdf = render_to_pdf('ticket_pdf_template.html', context)

        if pdf:
            response = pdf
            # Chipta brauzerda shunchaki ochilmasdan, telefonga fayl bo'lib yuklanishi shart:
            filename = f"Chipta_Sektor_{ticket.event_seat.seat.sector.name}_Joy_{ticket.event_seat.seat.seat_number}.pdf"
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            return response

        return HttpResponse("❌ PDF fayl generatsiya qilishda xatolik yuz berdi.", status=400)


class AdminDashboardView(LoginRequiredMixin, UserPassesTestMixin, TemplateView):
    template_name = 'dashboard.html'

    # QAT'IY FILTR: Faqat is_staff yoki is_superuser bo'lgan haqiqiy admin profillarni kiritadi!
    def test_func(self):
        return self.request.user.is_authenticated and (self.request.user.is_staff or self.request.user.is_superuser)

    def handle_no_permission(self):
        if self.request.user.is_authenticated:
            # Agar odam kirdi, lekin u admin emas (masalan Google bilan kirgan oddiy odam),
            # uni rad etish ogohlantirishi bilan to'g'ridan-to'g'ri bosh sahifaga otib yuboramiz!
            return redirect('/?error=Sizda_admin_panelga_kirish_huquqi_yoq')

        # Agar tizimga umuman kirmagan bo'lsa, login sahifasiga yo'naltiramiz
        return redirect('/auth/login/?next=/dashboard/')
