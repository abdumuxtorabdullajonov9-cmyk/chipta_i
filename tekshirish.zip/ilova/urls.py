# ilova/urls.py
#
# MUHIM TUZATISH: bu fayl avval "home", "ticket-3d", "auth/login" kabi HTML
# sahifalarini HAM o'z ichiga olar edi. Lekin bu fayl chipta_uz/urls.py da
# `path('api/', include('ilova.urls'))` orqali ulanganligi sababli, o'sha
# sahifalar aslida `/api/` prefiksi bilan (masalan `/api/auth/login/`) ochilar
# edi — bu esa boshqa joylardagi (masalan settings.LOGIN_URL, handle_no_permission
# ichidagi qattiq yozilgan `/auth/login/` manzili) haqiqiy manzillar bilan mos
# kelmas edi. Endi bu yerda FAQAT haqiqiy /api/ REST endpointlari qoladi;
# barcha HTML sahifalar chipta_uz/urls.py da, o'z (to'g'ri, /api/ siz) manzillarida
# ro'yxatdan o'tgan.

from django.urls import path
from .views import (
    AdminDashboardEventCreateView,
    AdminDashboardEventListView,
    AdminSectorGroupConfigView,
    ReserveSeatView,
    DownloadTicketPDFView,
    EventSeatListView,
)

urlpatterns = [
    # Admin & Xodim Dashboard API'lari (faqat is_staff/is_superuser — views.py da tekshiriladi)
    path('admin-dashboard/events/create/', AdminDashboardEventCreateView.as_view(), name='admin_event_create'),
    path('admin-dashboard/events/', AdminDashboardEventListView.as_view(), name='admin_event_list'),
    path('admin-dashboard/groups/config/', AdminSectorGroupConfigView.as_view(), name='admin_groups_config'),

    # Chipta va joy bilan bog'liq REST API'lar
    path('tickets/<uuid:ticket_uid>/download-pdf/', DownloadTicketPDFView.as_view(), name='download_ticket_pdf'),
    path('tickets/reserve/', ReserveSeatView.as_view(), name='ticket_reserve'),

    # 3D sahifa uchun: bitta sektorning 625 ta joyini (holati + narxi bilan) qaytaradi
    path('events/<int:event_id>/sectors/<int:sector_number>/seats/', EventSeatListView.as_view(),
         name='event_sector_seats'),
]
