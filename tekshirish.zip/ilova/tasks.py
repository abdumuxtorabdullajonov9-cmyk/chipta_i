from celery import shared_task
from .services import release_expired_reservations


@shared_task
def cleanup_expired_reservations():
    """Celery orqali har necha daqiqada bir marta chaqiriladigan davriy vazifa.
    Asosiy mantiq services.release_expired_reservations() da (services.py bilan bir xil
    kodni ikki joyda saqlamaslik uchun), chunki reserve_seats_service ham xuddi shu
    funksiyani har safar chaqirib, Celery ishlamay qolgan taqdirda ham joylar
    "abadiy band" bo'lib qolmasligini ta'minlaydi."""
    release_expired_reservations()
