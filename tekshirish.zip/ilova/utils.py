# ilova/utils.py
import io
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa


def render_to_pdf(template_src, context_dict={}):
    # HTML andozani yuklaymiz va ma'lumotlarni unga joylaymiz
    template = get_template(template_src)
    html = template.render(context_dict)

    # PDF faylni xotirada baytlar ko'rinishida yig'amiz
    result = io.BytesIO()

    # HTML andozasini UTF-8 formatida PDF ga render qilamiz
    pdf = pisa.pisaDocument(io.BytesIO(html.encode("UTF-8")), result)

    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None
